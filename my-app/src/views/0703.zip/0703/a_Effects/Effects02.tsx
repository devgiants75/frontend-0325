import React from 'react'

// 타이머 기능을 부수 효과로 사용
export default function Effects02() {
  // count 상태 초기화, 초기값은 0



  return (
    <div>

    </div>
  )
}

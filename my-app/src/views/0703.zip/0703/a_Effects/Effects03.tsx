import React from "react";

export default function Effects03() {


  // 마운팅 시 실행
  

  // count가 업데이트될 때 실행


  // name이 업데이트될 때 실행


  // 모든 렌더링마다 실행


  return (
    <div>
      
    </div>
  );
}

import React from 'react'

//! 간단한 사진 캡쳐 & 표시 기능
// - 웹캠으로 사진을 찍고, 찍은 사진을 화면에 표시
// - useState, useRef, useEffect

export default function Practice02() {
  // 웹캠의 비디오 스트림을 저장하기 위한 state


  // 비디오 HTML 요소에 접근하기 위한 ref
  // 캔버스 HTML 요소에 접근하기 위한 ref

  return (
    <div>
      <h1>카메라 앱</h1>
      
    </div>
  )
}

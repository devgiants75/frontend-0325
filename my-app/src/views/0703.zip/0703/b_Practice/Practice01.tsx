import React from 'react'

//! 사용자 정보 가져오기
// jsonplaceholder에서 users 데이터를 사용
// : 사용자 목록을 비동기적으로 호출

// 각 사용자의 이름과 이메일을 표시

export default function Practice01() {
  

  return (
    <div>
      <h3>Users 사용자 데이터 표시</h3>
      
    </div>
  )
}
